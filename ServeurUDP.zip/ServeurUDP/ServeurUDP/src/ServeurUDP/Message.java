/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurUDP;

/**
 *
 * @author march
 */
public class Message {
    String titre;
    String origine;
    String destinataire;
    String sujet;
    String contenu;
    boolean envoye;
    String msg="";
    
    public Message(String titre, String origine, String destinataire,
                    String sujet, String contenu){
        this.titre = titre;
        this.origine = origine;
        this.destinataire = destinataire;
        this.sujet = sujet;
        this.contenu = contenu;
        this.envoye = false;
        
    }
    
    String afficherMessage(){
        msg =  
                "\nTitre : " +titre
                +"\nOrigine : " +origine
                +"\nDestinataire : " +destinataire
                +"\nSujet : " +sujet
                +"\nContenu : " +contenu
                +"\n";
        return msg;
    }
}
