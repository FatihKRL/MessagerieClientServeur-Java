/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurUDP;

import java.util.ArrayList;

/**
 *
 * @author march
 */
public class Utilisateur {
    String login,pwd;
    ArrayList<Contact> a;
    Contact vide;
    String txt="";
    boolean apresent = false;
    int nbAmi;
    boolean connecte;
    
    Utilisateur(String login,String pwd){
        this.login = login;
        this.pwd = pwd;
        a = new ArrayList(10);
        nbAmi = 0;
        connecte = false;
    }   
    void nouvelAmi(String ami){
        apresent = false;
        if(nbAmi < 10){
            for(int i=0; nbAmi > i ; i++){
                if(ami.equals(a.get(i).login)){
                    apresent = true;
                }
            }
            if(!apresent){
                a.add(new Contact(ami));
                nbAmi++;
            }
            
        }
    }
    boolean chercheAmi(String ami){
        for(int i=0; a.size() > i ; i++){
                if(ami.equals(a.get(i).login)){
                    return true;
                }
            }
        return false;
    } 
    void acceptAmi(String ami){
        for(int i=0; nbAmi > i ; i++){
                if(ami.equals(a.get(i).login)){
                    a.get(i).accepte();
                   
                }
            }
    }
    void refusAmi(String ami){
        for(int i=0; nbAmi > i ; i++){
                if(ami.equals(a.get(i).login)){
                    a.remove(i);
                   nbAmi--;
                }
            }
    }    
    Contact chercheAmiObj(String ami){
        for(int i=0; a.size() > i ; i++){
                if(ami.equals(a.get(i).login)){
                    return a.get(i);
                }
            }
        return null;
    }    
    void nouveauMessage(String titre, String origine, String destinataire,
                    String sujet, String contenu, String ami){
        for(int i= 0; i < nbAmi ; i++){
            if (a.get(i).login.equals(ami)){
                a.get(i).nouveauMessage(titre, origine, destinataire,
                     sujet, contenu);
            }
        }
    }
}
