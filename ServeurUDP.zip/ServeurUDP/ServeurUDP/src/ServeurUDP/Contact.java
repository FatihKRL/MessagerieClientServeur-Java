/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurUDP;

import java.util.ArrayList;

/**
 *
 * @author march
 */
public class Contact {
    String login;
    ArrayList<Message> m;
    int nbMessage;
    boolean attente;
    boolean mpresent= false;
    String txt="";
    
    public Contact(String login){
        this.login = login;
        m = new ArrayList();
        nbMessage = 0;
        attente = true;
    }
    void accepte(){
        attente= false;        
    }    
    String consulterMessage(String origine){
        mpresent =false;
        txt="";
        for(int i= 0; i < nbMessage ; i++){
                if (m.get(i).origine.equals(origine)){
                    txt += m.get(i).afficherMessage();
                    mpresent = true;
                }
        }
        if(mpresent){
            return txt;
        }else{
            return "\n[SERVEUR]Vous n'avez aucun message";
        }
        
    }    
    boolean estAccepte(){
        return !attente;
    }
    void nouveauMessage(String titre, String origine, String destinataire,
                    String sujet, String contenu){
        if (nbMessage < 10){
            m.add(new Message( titre, origine, destinataire,
                    sujet, contenu));
            nbMessage++;     
        }else{
            m.remove(0);
            m.add(new Message( titre, origine, destinataire,
                    sujet, contenu));
        }
    }
}
