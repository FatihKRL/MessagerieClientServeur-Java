/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ServeurUDP;

/**
 *
 * @author march
 */
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ServeurUDP {
    Utilisateur listUtilisateur[] = new Utilisateur[10];
    int nbUtilisateur = 0;
    int numArg=0;
    String arg[] = new String[10];
    String msgfin;
    static  final int port = 6010 ;
    DatagramSocket socket;
    DatagramPacket paquetRecu;
    Utilisateur login;

    String recu() throws UnknownHostException, SocketException, IOException {
        byte [] buffer  = new byte [1024] ;
        String str ;
        paquetRecu =
             new DatagramPacket(buffer, buffer.length);
        socket.receive(paquetRecu) ;
        return new String(buffer, 0, 0, paquetRecu.getLength());
    }
    
    void envoi(String msg) throws UnknownHostException, SocketException, IOException {
        byte [] buffer  = new byte [1024] ;
        String str ;
        InetAddress clientAddress = paquetRecu.getAddress();
        int msglen = msgfin.length() ;
        byte [] message = new byte [msglen] ;
        msgfin.getBytes(0, msglen, message, 0) ;
        DatagramPacket response = new DatagramPacket(message , msglen , clientAddress , paquetRecu.getPort() );
        socket.send(response); 
    }
    boolean login(){
        if(arg[0].equals("connexion")){
            for(int i = 0 ; nbUtilisateur > i ; i++){
               if(arg[1].equals(listUtilisateur[i].login)){
                   if(arg[2].equals(listUtilisateur[i].pwd)){
                        return true;
                    }else{
                       msgfin +="\n [SERVEUR] Le mot de passe n'est pas bon";
                   }
               } 
            }
        }
        return false;
    }
    boolean loginlog(){
        if(arg[0].equals("connexion") 
                && arg[3].equals("log")){
            for(int i = 0 ; nbUtilisateur > i ; i++){
               if(arg[1].equals(listUtilisateur[i].login)){
                   if(arg[2].equals(listUtilisateur[i].pwd)){
                        return true;
                    }else{
                       msgfin +="\n [SERVEUR] Le mot de passe n'est pas bon";
                   }
               } 
            }
        }
        return false;
    }
    boolean nouvel_ami(){
       
        if(arg[3].equals("nouvelami")
                && (wholog().login.equals(arg[4]))== false){
            if(nbUtilisateur > 0){
                for(int i = 0 ; nbUtilisateur > i ; i++){
                    if(arg[4].equals(listUtilisateur[i].login)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    boolean requete(String requete){
       
        if(arg[3].equals(requete)){
            if(nbUtilisateur > 0){
                for(int i = 0 ; nbUtilisateur > i ; i++){
                    if(arg[4].equals(listUtilisateur[i].login)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    boolean requetemsg(String requete){
       
        if(arg[3].equals(requete)){
            if(nbUtilisateur > 1){
                for(int i = 0 ; nbUtilisateur > i ; i++){
                    if(arg[4].equals(listUtilisateur[i].login)){
                        return true;
                    }
                }
            }
        }
        return false;
    }
    Utilisateur wholog(){
        if(arg[0].equals("connexion")){
            if(nbUtilisateur > 0){
                for(int i = 0 ; nbUtilisateur > i ; i++){
                    if (arg[1].equals(listUtilisateur[i].login)){
                        login = listUtilisateur[i];
                    }
                }
                return login;
            }
        }
       
            return login;
    }
    Utilisateur target(){
        if(nbUtilisateur > 0){
            for(int i = 0 ; nbUtilisateur > i ; i++){
                if (arg[4].equals(listUtilisateur[i].login)){
                    login = listUtilisateur[i];
                }
            }
            return login;
        }
            return null;
    }
    public  ServeurUDP() throws SocketException, IOException{
        socket = new DatagramSocket(port) ;
      
      for ( ; ; ) {
        login = new Utilisateur("","");
        msgfin="";
        for(int i = 0; 10 > i; i++){
            arg[i]="";
        }
        String str = recu();
        String[] arrOfStr = str.split("@");
        
        numArg = 0;
        for (String a : arrOfStr){
            arg[numArg] = a;
            numArg++;
        }
        if(arg[0].equals("inscription") & (nbUtilisateur < 10)){
            
            boolean present = false;
            if(nbUtilisateur > 0){
                for(int i = 0 ; nbUtilisateur > i ; i++){
                    if(arg[1].equals(listUtilisateur[i].login)){
                       present = true;
                   } 
                }
            }
            if(!present){
                listUtilisateur[nbUtilisateur] = new Utilisateur(arg[1], arg[2]);   
                
                System.out.println("\n-== La liste des utilisateurs a ete actualise ==-");
                for (int i = 0 ; nbUtilisateur >= i ; i++){
                    System.out.println(listUtilisateur[i].login);
                }   
                nbUtilisateur++;
                msgfin += "\n[SERVEUR] L'utilisateur a ete ajoute a la liste avec succes";  
            } else {
                msgfin += "\n[SERVEUR] L'utilisateur est deja present";
            }
         
        }else if(arg[0].equals("connexion")
                && loginlog()){
            if(loginlog()){
                msgfin +="connexion_accept";
            }else{
                msgfin +="connexion_refus";
            }
            
 
        }else if((login()) && (nouvel_ami())){
            target().nouvelAmi(arg[1]);
            msgfin += "\n[SERVEUR] Demande d'ami envoye avec succes";
        }else if((login()) && requete("acceptami") && wholog().chercheAmi(arg[4])){
            wholog().acceptAmi(arg[4]);
            target().nouvelAmi(arg[1]);
            target().acceptAmi(arg[1]);
            msgfin += "\n[SERVEUR] Demande d'ami accepte";

        }else if((login()) && requete("refusami") && wholog().chercheAmi(arg[4])){
            wholog().refusAmi(arg[4]);

        }else if(login() 
                && requete("message") 
                && nbUtilisateur > 0  && wholog().chercheAmi(arg[4])){
            
            msgfin += "\n-=== Voici vos messages ==-";
            msgfin += "\n[SERVEUR] Votre message a bien ete envoye a " +arg[4];
            
            wholog().nouveauMessage(arg[5],arg[1],arg[4],arg[6],arg[7],target().login);
            target().nouveauMessage(arg[5], arg[1],arg[4],arg[6],arg[7],wholog().login);
        }else if(arg[0].equals("consulte") && arg[1].equals("utilisateur") && nbUtilisateur > 0){
            msgfin += "\n_== Voici_la_liste_des_utilisateurs ==_";
            for (int i = 0 ; nbUtilisateur > i ; i++){
                    msgfin += "\n-"+listUtilisateur[i].login;
            }  
        }else if((login()) 
                && (arg[3].equals("consulte"))
                && (arg[4].equals("amis")) 
                && ((wholog().nbAmi) > 0)){
            msgfin += "\n_== Voici_votre_liste_d'amis ==_";
            for (int i = 0 ; wholog().nbAmi > i ; i++){
                msgfin += "\n-" +wholog().a.get(i).login;
                if(wholog().a.get(i).attente){
                    msgfin += "_en_attente";
                } else{
                    msgfin += "_accepte";
                }
                
            }  
        }else if(login() 
                && arg[3].equals("consulte")
                && arg[5].equals("message")
                && wholog().chercheAmi(arg[4])){
            msgfin += "\n-== Voici votre conversation avec " +arg[4] +"==-";
            msgfin += target().chercheAmiObj(arg[1]).consulterMessage(arg[4]); 
        }else{           
            msgfin += "\n[SERVEUR] Le serveur ne peut pas repondre a votre requete";
            
            if(nbUtilisateur > 10){
            msgfin += "\n [SERVEUR] Le nombre d'utilisateur max a ete atteint";
            }
            if(arg[3].equals("nouvelami") 
                    && !(nouvel_ami())
                    && (wholog().login.equals(arg[4]))== false){
                msgfin += "\n[SERVEUR] Le destinataire n'existe pas";
            }
            if( (arg[3].equals("acceptami") || arg[3].equals("refusami")) 
                    && (wholog().nbAmi == 0)){
                msgfin += "\n[SERVEUR] Vous n'avez aucune demande d'ami en attente";
            }
            if((wholog().nbAmi == 0) 
                    && arg[3].equals("consulte") 
                    && arg[4].equals("amis")){
                msgfin +="\n[SERVEUR] Vous n'avez pas d'amis :( ";
            }
        }
        envoi(msgfin);
      }
    }
    public  static void main(String args[])
    throws SocketException, IOException {
        ServeurUDP saeServeurudp = new ServeurUDP();
    }

}
