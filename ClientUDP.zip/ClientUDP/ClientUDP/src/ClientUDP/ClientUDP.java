/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClientUDP;

/**
 *
 * @author march
 */

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Scanner;
public class ClientUDP {
    static final int port = 6010;
    DatagramSocket socket;
    DatagramPacket envoye, recu;
    InetAddress address;
    String msg;
    
    void envoi(String msg) throws UnknownHostException, SocketException, IOException {
        int msglen = msg.length() ;
        byte [] message = new byte [msglen] ;
        message = msg.getBytes() ;
        envoye = new DatagramPacket(message, msglen, address, port) ;
        socket.send(envoye) ;   
    }
  
    String recu() throws UnknownHostException, SocketException, IOException {
      byte[] buf = new byte[1000];
      recu = new DatagramPacket(buf, buf.length);
      socket.receive(recu);
      return new String(recu.getData(), 0, recu.getLength());
    }
  
    ClientUDP() throws UnknownHostException, SocketException, IOException{
        address = InetAddress.getByName("127.0.0.1") ;
        socket = new DatagramSocket() ;
        UserInterface interface1 = new UserInterface(); 
        interface1.setVisible(true);
        Scanner clavier=new Scanner(System.in);
        System.out.println("-== Liste des commandes ==-") ;
        System.out.println("inscription@login_d'inscription@mot_de_passe") ;
        System.out.println("\nSi vous desirez envoyer des messages a partir"
                + "d'un login vous devrer indiquer le login dans la premiere instruction"
                + "\nconnexion@votre_login@mot_de_passe@nouvelami@destinataire"
                + "\nconnexion@votre_login@mot_de_passe@acceptami@destinataire" 
                + "\nconnexion@votre_login@mot_de_passe@refusami@destinataire"
                + "\nconnexion@votre_login@mot_de_passe@message@destinataire@mention@sujet@contenu"
                + "\n\nVous pouvez consulter differentes listes tels que :"
                + "\nListe des utilisateurs avec consulte@utilisateur"
                + "\nListe des amis avec votre_login@mot_de_passe@consulte@amis"
                + "\nListe des messages avec votre_login@mot_de_passe@consulte@votre_ami@message@") ;

      }
    public static void main(String args[])
    throws UnknownHostException, SocketException, IOException {
      
      ClientUDP clientudp = new ClientUDP();
      
  }
}

